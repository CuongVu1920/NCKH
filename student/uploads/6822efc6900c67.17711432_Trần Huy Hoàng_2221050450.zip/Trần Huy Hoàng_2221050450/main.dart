import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Screen(),
    );
  }
}

class Screen extends StatefulWidget {
  @override
  _ScreenState createState() => _ScreenState();
}

class _ScreenState extends State<Screen> {
  final fakeWeatherData = {
    'Hà Nội': {
      'temperature': 32,
      'condition': 'Nắng đẹp',
      'humidity': 55,
      'wind': 12,
      'timeline': [
        {'time': 'Sáng', 'temp': 28, 'icon': Icons.wb_sunny},
        {'time': 'Trưa', 'temp': 32, 'icon': Icons.wb_sunny},
        {'time': 'Chiều', 'temp': 30, 'icon': Icons.cloud_queue},
        {'time': 'Tối', 'temp': 26, 'icon': Icons.nightlight_round},
      ],
    },
    'Hồ Chí Minh': {
      'temperature': 34,
      'condition': 'Nhiều mây',
      'humidity': 60,
      'wind': 10,
      'timeline': [
        {'time': 'Sáng', 'temp': 29, 'icon': Icons.wb_sunny},
        {'time': 'Trưa', 'temp': 34, 'icon': Icons.wb_sunny},
        {'time': 'Chiều', 'temp': 33, 'icon': Icons.cloud},
        {'time': 'Tối', 'temp': 28, 'icon': Icons.nightlight_round},
      ],
    },
    'Đà Nẵng': {
      'temperature': 29,
      'condition': 'Mưa nhẹ',
      'humidity': 70,
      'wind': 15,
      'timeline': [
        {'time': 'Sáng', 'temp': 25, 'icon': Icons.cloud},
        {'time': 'Trưa', 'temp': 29, 'icon': Icons.wb_cloudy},
        {'time': 'Chiều', 'temp': 27, 'icon': Icons.cloud},
        {'time': 'Tối', 'temp': 24, 'icon': Icons.nightlight_round},
      ],
    },
  };

  String selectedCity = 'Hà Nội';

  @override
  Widget build(BuildContext context) {
    final cityData = fakeWeatherData[selectedCity];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 0, 128, 219),
        title: const Text(
          "Thời tiết hôm nay",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
      ),
      backgroundColor: const Color.fromARGB(255, 0, 128, 219),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Địa điểm",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.blue, width: 1),
                  color: const Color.fromARGB(255, 144, 224, 232),
                ),
                child: SizedBox(
                  width: 200,
                  child: DropdownButton<String>(
                    value: selectedCity,
                    isExpanded: true,
                    icon: const Icon(Icons.arrow_drop_down, size: 20),
                    underline: const SizedBox(),
                    items:
                        fakeWeatherData.keys.map((city) {
                          return DropdownMenuItem(
                            value: city,
                            child: Text(
                              city,
                              style: const TextStyle(fontSize: 14),
                            ),
                          );
                        }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          selectedCity = value;
                        });
                      }
                    },
                    style: const TextStyle(fontSize: 14, color: Colors.black),
                    dropdownColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              Container(
                padding: const EdgeInsets.all(100),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    Icon(
                      cityData!['condition'] == 'Nắng đẹp'
                          ? Icons.wb_sunny
                          : cityData['condition'] == 'Nhiều mây'
                          ? Icons.cloud
                          : Icons.cloudy_snowing,
                      size: 60,
                      color: Colors.orange,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "${cityData['temperature']}°C",
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      " ${cityData['condition']}",
                      style: TextStyle(
                        color: const Color.fromARGB(255, 205, 203, 203),
                      ),
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Icon(Icons.opacity, color: Colors.blue),
                        SizedBox(width: 105),
                        Icon(Icons.air, color: Colors.blue),
                      ],
                    ),
                    Row(
                      children: [
                        Text("${cityData['humidity']}%"),
                        SizedBox(width: 90),
                        Text("${cityData['wind']}km/h"),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          "Độ ẩm",
                          style: TextStyle(
                            color: const Color.fromARGB(255, 205, 203, 203),
                          ),
                        ),
                        SizedBox(width: 90),
                        Text(
                          "Gió",
                          style: TextStyle(
                            color: const Color.fromARGB(255, 205, 203, 203),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              const Text(
                "Thời tiết trong ngày",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 80,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children:
                      (cityData['timeline'] as List).map<Widget>((entry) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: Column(
                            children: [
                              Icon(entry['icon'], size: 30),
                              Text("${entry['temp']}°C"),
                              Text(entry['time']),
                            ],
                          ),
                        );
                      }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
